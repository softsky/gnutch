@artifact.package@

class @artifact.name@ {
    def configure = {
        // example:
        // from('seda:input').to('stream:out')
    }
}
