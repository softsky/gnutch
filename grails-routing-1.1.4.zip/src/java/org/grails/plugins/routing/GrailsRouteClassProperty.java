package org.grails.plugins.routing;

public interface GrailsRouteClassProperty {
    public static final String CONFIGURE = "configure";
    public static final String ROUTE = "Route";
}
